# azure-mlops
This repository is used for MLOps using models created on Azure Databricks.
